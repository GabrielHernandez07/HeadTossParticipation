﻿using System;

namespace HeadTossParticipation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pick Heads or Tails >>");
            string result = Console.ReadLine();


            Random rand = new Random();
            int randValue = rand.Next(1, 3);
           
            if (randValue == 1)
            {
                Console.WriteLine("Heads");

                result = "Heads";
            }
            else if (randValue == 2)
            {
                Console.WriteLine("Tails");

                result = "Tails";
            }
            else

                Console.WriteLine(randValue);
        }
    }
}
